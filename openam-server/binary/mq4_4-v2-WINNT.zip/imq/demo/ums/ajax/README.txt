@(#)README      1.0 09/09/08

UMS APIs examples

Description
-----------
This directory contains Ajax examples that illustrates the use of the
UMS APIs to send and receive simple text message.

Files
-----
SendMsg.html		Source file for Ajax client that sends
			text message to a UMS server.
ReceiveMsg.html		Source file for Ajax client that receives
			text message from a UMS server.
README			This file.

Minimum Browser Requirements
----------------------------
Require Firefox 2 and higher or Internet Explorer 6 and higher.
In your browser, you must enable JavaScript.
