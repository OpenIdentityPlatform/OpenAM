JMS Bridge Examples
-------------------

Directory     Description
---------     -----------
mqtomq        An example of JMS Bridge that bridges 2 MQ brokers
