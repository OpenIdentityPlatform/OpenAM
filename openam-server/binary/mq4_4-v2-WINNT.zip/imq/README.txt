		         Sun GlassFish(tm) Message Queue
                                    README
                         -------------------------------
                           Last updated: 25 March 2009

This file provides a quick reference to Sun GlassFish(tm) Message Queue
information and customer resources.

If you are installing Message Queue for the first time, please read the Message
Queue Technical Overview, Release Notes, and Installation Guide before
installing Sun GlassFish(tm) Message Queue.

If you are upgrading the productfrom an earlier release, make sure to read the
Release Notes and the upgrade information in Chapter 1 of the Installation
Guide.
  
This file contains the following sections:

WHERE TO FIND PRODUCT DOCUMENTATION 
WHERE TO FIND PRODUCT INFORMATION AND NEWS 
WHERE TO SEND FEEDBACK AND QUESTIONS 
WHERE TO GO NEXT


===================================
WHERE TO FIND PRODUCT DOCUMENTATION 
===================================

Documentation for the Sun GlassFish(tm) Message Queue 4.4 release 
can be found on the following web site:

	http://docs.sun.com/coll/1307.7

Be sure to check the Documentation Center at that location for a topical
reference to all books in the documentation set.

Message Queue documentation components are in PDF and HTML format:

  - PDF files can be viewed in your web browser (with an appropriate 
    plugin) or in Adobe Acrobat Reader. Most recent browsers 
    include the PDF reader plugin. If your browser does not, you 
    can download the plugin from the browser vendor's web site or 
    the Adobe web site at:
        http://www.adobe.com/products/acrobat/readstep.html

  - HTML files can be viewed in your web browser.

DOCUMENTATION CENTER
Provides an index and direct links to all topics covered in the product
documentation.

TECHNICAL OVERVIEW
Explains the concepts, terminology, architecture, features, components, and
other basics needed to use the Message Queue product.

RELEASE NOTES
Includes descriptions of new features, limitations, and known bugs, as well
as technical notes.
 
INSTALLATION GUIDE
Explains how to install Message Queue on the Solaris, Linux, AIX, and Windows 
platforms.

DEVELOPER'S GUIDE FOR JAVA CLIENTS
For Java clients: Provides an introduction, a quick-start 
tutorial, and programming information for developers of Java client programs
using the Message Queue implementation of the JMS or SOAP/JAXM APIs. 

ADMINISTRATION GUIDE
Provides background and information needed to perform administration tasks
using Message Queue administration tools.

DEVELOPER'S GUIDE FOR C CLIENTS
For C clients: Provides programming and reference documentation for developers
of C client programs using the Message Queue C implementation of the
JMS API (C-API).

DEVELOPER'S GUIDE FOR JMX CLIENTS
For JMX administration clients: Provides programming and reference documentation
for developers of JMX client programs using the Message Queue JMX API.

API DOCUMENTATION
Includes standard JMS API documentation as well as Message-Queue-specific APIs 
for Message Queue administered objects. This documentation is installed with 
the product and can be found at the following location:

    /usr/share/javadoc/imq  (SVR4 Packaging) 
    /opt/sun/mq/javadoc/ (Linux RPMs) 
    <mq_root>/javadoc/ (all others)
        where <mq_root> is the directory in which Sun GlassFish(tm) Message 
	  Queue has been installed.

==========================================
WHERE TO FIND PRODUCT INFORMATION AND NEWS 
==========================================

For the most current information on 
    * Product News and Reviews 
    * Release Notes and Product Documentation 
    * Technical Support Contact Information
Visit the product web site at:
    http://www.sun.com/software/message_queue

For answers to common questions about using the Sun GlassFish(tm) Message
Queue product, see Frequently Asked Questions (FAQ) documentation at:
    http://www.sun.com/software/products/message_queue/faqs_message_queue.html

or the Sun GlassFish(tm) Message Queue Forum at: 
    http://forums.sun.com/forum.jspa?forumID=711

====================================
WHERE TO SEND FEEDBACK AND QUESTIONS 
====================================

To report a new bug, submit a comment, or ask a question, 
send us an email at:
    mq-feedback@sun.com

================
WHERE TO GO NEXT 
================

Please read the Message Queue Release Notes for supported platforms and
products and for information specific to this release of the product. If you
are new to the product, also read the Message Queue Technical Overview before
using the procedure in the Message Queue Installation Guide to install the
product.

We recommend that you also check the FAQ documentation for answers 
to common questions.
