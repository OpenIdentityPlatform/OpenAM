
                       Sun GlassFish(tm) Message Queue 
                                Version 4.4


Any .jar or .zip file placed in this directory ($IMQ_VARHOME/lib on Unix
and %IMQ_VARHOME%\lib on Windows) is added to the Broker's CLASSPATH. 
Typically this is only used when configuring JDBC support for the
Broker's persistent store or when configuring JAAS LoginModules for
the Broker's JAAS authentication support.


